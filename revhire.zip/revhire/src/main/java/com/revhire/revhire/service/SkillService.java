package com.revhire.revhire.service;

public interface SkillService {

    boolean addSkillToResume(int resumeId, String skillName);
}
