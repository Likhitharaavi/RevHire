package com.revhire.revhire.service;

public interface ResumeSkillService {

    boolean addSkillToResume(int resumeId, String skillName);
}
