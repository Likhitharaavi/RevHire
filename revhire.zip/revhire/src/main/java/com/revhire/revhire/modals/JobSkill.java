package com.revhire.revhire.modals;

public class JobSkill {

    private int jobId;
    private int skillId;
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

    // getters and setters
}

