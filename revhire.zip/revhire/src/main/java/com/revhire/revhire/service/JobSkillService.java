package com.revhire.revhire.service;

public interface JobSkillService {

    boolean addSkillToJob(int jobId, String skillName);
}


